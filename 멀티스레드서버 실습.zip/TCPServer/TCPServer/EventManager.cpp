#include "EventManager.h"


EventManager::EventManager()
{

}