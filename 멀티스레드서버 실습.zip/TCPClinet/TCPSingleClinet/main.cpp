#include "TCPClient.h"

int main()
{
	UTCPClient client;
	client.RunClient();
	return 0;
}
